<?php
  $conn = mysqli_connect("localhost", "root", "", "blogging-system-php");

  if (!$conn) {
    echo "Connection Failed.";
  }
?>
